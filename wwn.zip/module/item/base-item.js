
/**
 * Override and extend the basic :class:`Item` implementation
 */
export class WwnBaseItem extends Item {

}
